# User Management Service

Este projeto é um micro serviço para gerenciamento de usuários com funcionalidades de criação, login, troca de senha e listagem de usuários bloqueados.

## Estrutura do Projeto

